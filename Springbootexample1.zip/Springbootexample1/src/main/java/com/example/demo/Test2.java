package com.example.demo;

import org.springframework.stereotype.Component;

@Component("ob2")
public class Test2 
{
	public int sub(int a,int b)
	{
		return a-b;
	}
}
