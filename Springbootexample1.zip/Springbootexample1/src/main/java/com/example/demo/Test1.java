package com.example.demo;

import org.springframework.stereotype.Component;

@Component("ob1")
public class Test1 
{
public void welcome()
{
	System.out.println("welcome to SpringBoot");
}
public int sum(int a,int b)
{
	return a+b;
}
}
