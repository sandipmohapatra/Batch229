package com.example.demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Springbootexample1Application {

	public static void main(String[] args)
	{
		ApplicationContext ac= SpringApplication.run(Springbootexample1Application.class, args);
		Test1 obj=ac.getBean("ob1",Test1.class);
		Test2 obj1=ac.getBean("ob2",Test2.class);
		obj.welcome();
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter 2 nos");
		int a=ob.nextInt();
		int b=ob.nextInt();
		System.out.println("The sum is "+obj.sum(a, b));
		
		System.out.println("Enter 2 nos");
		int c=ob.nextInt();
		int d=ob.nextInt();
		System.out.println("The subtraction  is "+obj1.sub(c, d));
	}

}
