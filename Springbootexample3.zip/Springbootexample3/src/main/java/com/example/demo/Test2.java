package com.example.demo;

import org.springframework.stereotype.Component;

//ctrl+shift+O
@Component("test1")
public class Test2 
{
public void welcomeMphasis()
{
	System.out.println("welcome to Rest WebServices Mphasis Batch215");
}
public int mul(int a,int b)
{
	return a*b;
}

public int div(int a,int b)
{
	return a / b;
}

}
