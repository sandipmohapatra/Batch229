import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
    public static void main(String[] args) {
        Logger logger = LoggerFactory.getLogger(App.class);
 
        logger.info("This is an information message");
        logger.error("this is a error message");
        logger.warn("this is a warning message");
        Wombat ob=new Wombat();
        ob.oldT=45;
        ob.t=55;
        ob.setTemperature(47);
        for(int i=1;i<=10;i++)
        {
        	System.out.println("welcome to debug");
        }
           }
}